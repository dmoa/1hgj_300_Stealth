function love.conf(t)
    t.window.title = "Stealthy Ninja"
    t.window.icon = "ninja.jpeg"
end